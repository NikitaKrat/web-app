from enum import Enum


class Size(Enum):
    Small = 0,
    Normal = 1,
    Long = 2,


order_sizes = {
    "Normal" : {
        'heigh' : 145,
        'width' : 133,
        'margin_top' : -2,
        'text_size' : 8,
        'border_radius' : 16,
        'button_border_radius' : 5,
        'button_width' : 74,
        'button_heigh' : 24,
        'button_text_size' : 8,
        'button_margin_top' : -4,
    },

    "Small" : {
        'heigh' : 110,
        'width' : 87,
        'margin_top' : -5,
        'text_size' : 7,
        'border_radius' : 10,
        'button_border_radius' : 3,
        'button_width' : 46,
        'button_heigh' : 17,
        'button_text_size' : 6,
        'button_margin_top' : -5,
    },

    "Long" : {
        'heigh' : 192,
        'width' : 133,
        'margin_top' : -2,
        'text_size' : 8,
        'border_radius' : 16,
        'button_border_radius' : 5,
        'button_width' : 74,
        'button_heigh' : 24,
        'button_text_size' : 8,
        'button_margin_top' : -4,
    },
}


class ContainerInfo:
    def __init__(self, img_url, text, price, colors, text_color, desciption, size: str):
        self.img_url = img_url
        self.text = text
        self.colors = colors
        self.text_color = text_color
        self.price = price
        self.desciption = desciption
        
        self.heigh = order_sizes[size]['heigh']
        self.width = order_sizes[size]['width']
        self.margin_top = order_sizes[size]['margin_top']
        self.text_size = order_sizes[size]['text_size']
        self.border_radius = order_sizes[size]['border_radius']
        self.button_border_radius = order_sizes[size]['button_border_radius']
        self.button_width = order_sizes[size]['button_width']
        self.button_heigh = order_sizes[size]['button_heigh']
        self.button_text_size = order_sizes[size]['button_text_size']
        self.button_margin_top = order_sizes[size]['button_margin_top']


    def __str__(self) -> str:
        return f"ContainerInfo: {self.img_url}, {self.text}, {self.colors}, {self.desciption}"
