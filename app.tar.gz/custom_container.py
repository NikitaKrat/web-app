from orders import OrderNames
import flet as ft
import asyncio
from dialog_menu import DialogPayment, show_dilaog
from container_info import ContainerInfo, Size, order_sizes
import requests
from cfg import URL_TUNEL
import json



order_container_bg_color_default = ["0x10A0A3", "0x132B51",]
order_gems_text_color = "0xFFFFFF"
bg_color_dark = "0x181F33"


# OrderNames -> ContainerInfo
order_container_info = {
    OrderNames.order_clash_royale_gold_passroyale : ContainerInfo(
        img_url=1,
        text='Золотой Пропуск',
        price=100,
        colors=[
                "0xFFDC20",
                "0xF5A500",
        ],
        text_color="0x6C3028",
        desciption="Продвигайтесь в сезоне Pass Royale, зарабатывая невероятные награды, включающие элементы оформления, дополнительные ресурсы и эксклюзивные привилегии!",
        size="Normal",
    ),
    
    OrderNames.order_clash_royale_diamond_passroyale : ContainerInfo(
        img_url=1,
        text='Алмазный Пропуск',
        price=10000,
        colors=[
                "0x96FAFE",
                "0xFAB4F5",
                "0xFFDC20",
        ],
        text_color="0x553C50",
        desciption="Полная версия Pass Royale во всем своем великолепии! Продвигайтесь в сезоне Pass Royale, зарабатывая невероятные награды, включающие элементы оформления, дополнительные ресурсы и эксклюзивные привилегии!",
        size="Normal",
    ),
    
    OrderNames.order_clash_royale_gems_80 : ContainerInfo(
        img_url=1,
        text='Пригошня кристалов',
        price=20,
        colors=order_container_bg_color_default,
        text_color="0xFFFFFF",
        desciption="80 Гемов",
        size="Small",
    ),
}



class CustomContainer(ft.UserControl):
    def __init__(self, order_name: OrderNames):
        super().__init__()

        self.order_name = order_name
        self.container : ft.Container = self.get_order_container()
    
    async def on_button_click(self, event: ft.ContainerTapEvent) -> None:
        self.container.scale = 0.9
        await self.update_async()

        await asyncio.sleep(0.2)

        self.container.scale = 1
        await self.update_async()

        r = requests.get(url=URL_TUNEL + f"/order_info?order_name={self.order_name}").json()
        container_info = ContainerInfo(**r)

        await show_dilaog(self.page, DialogPayment(self.page, container_info))

    def get_order_container(self) -> ft.Container:
        r = requests.get(url=URL_TUNEL + f"/order_info?order_name={self.order_name}").json()
        container_params = ContainerInfo(**r)

        img = ft.Image(
            src=container_params.img_url,
            width=400,
            fit=ft.ImageFit.CONTAIN,
        )
        
        txt = ft.Text(
            value=container_params.text,
            weight=ft.FontWeight.W_300,
            text_align=ft.TextAlign.CENTER,
            color=container_params.text_color,
            size=container_params.text_size,
        )
        
        txt_container = ft.Container(
            content=txt,
            alignment=ft.alignment.center,
            width=container_params.width,
            margin=ft.Margin(0, container_params.margin_top, 0, 0),
        )
    
        button = ft.Container(
            content=ft.Text(f"{container_params.price}р", size=container_params.button_text_size, color="0xFFFFFF"),
            width=container_params.button_width,
            height=container_params.button_heigh,
            bgcolor="0x000000",
            border_radius=container_params.button_border_radius,
            alignment=ft.alignment.center,
            margin=ft.Margin(0, container_params.button_margin_top, 0, 0),
        )
        
        column = ft.Column(
            [
                img,
                txt_container,
                button,
            ],
            
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            height=container_params.heigh,
            width=container_params.width,
        )

        order_container = ft.Container(
            content=column,
            border_radius=ft.border_radius.all(container_params.border_radius),
            gradient=ft.LinearGradient(
                colors=container_params.colors,
                tile_mode=ft.GradientTileMode.MIRROR,
                rotation=-0.3,
            ),
            width=container_params.width,
            height=container_params.heigh,
            alignment=ft.alignment.center,
            on_click=self.on_button_click,
            animate_scale=ft.Animation(duration=800, curve=ft.AnimationCurve.EASE)
        )
        
        return order_container
    
    def build(self):
        return self.container
