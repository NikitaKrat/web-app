# -*- coding: utf-8 -*-

import asyncio
import requests
import flet as ft
from flet_core import event
from orders import OrderNames
from custom_container import CustomContainer, order_sizes, bg_color_dark
from container_info import ContainerInfo, Size, order_sizes
from cfg import URL_TUNEL
import aiohttp


def get_spacing(page_windth: int, len: int, container_width) -> int:
    return max((page_windth - len * container_width) / (len + 1) - 10, 20)


async def close():
    print("close")


async def main(page: ft.Page):
    page.title = "Mamoshop"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = bg_color_dark
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.fonts = {
        "KZSupercell-Magic" : f"fonts/KZSupercell-Magic.ttf",
        "Ubuntu-Regular" : f"fonts/Ubuntu-Regular.ttf",
        "RussoOne-Regular" : f"fonts/RussoOne-Regular.ttf",
        "DidactGothic-Regular" : f"fonts/DidactGothic-Regular.ttf",
        }
    page.theme = ft.Theme(font_family="KZSupercell-Magic")

    labels = requests.get(url=URL_TUNEL + "/labels")
    labels = labels.json()

    async def page_resize(e):
        s = get_spacing(page.width, len(passes_list), order_sizes["Normal"]['width'])
        passes_order_size.spacing = s
        s = get_spacing(page.width, len(gems_list), order_sizes["Small"]['width'])
        gems_order_size.spacing = s
        await page.update_async()
        
    page.on_resize = page_resize
    page.scroll = ft.ScrollMode.ALWAYS
    page.padding = 0


    ''' LABELS '''
    label_passes = ft.Image(
        src=labels['clash_royale_label_passes_url'],
        fit=ft.ImageFit.CONTAIN,
        scale=0.9,
    )
    
    label_time = ft.Image(
        src=labels['clash_royale_label_time_url'],
        fit=ft.ImageFit.CONTAIN,
        scale=0.9,
    )
    
    label_gems = ft.Image(
        src=labels['clash_royale_label_gems_url'],
        fit=ft.ImageFit.CONTAIN,
        scale=1.1,
    )
    

    passes_list = [
        CustomContainer(OrderNames.order_clash_royale_gold_passroyale),
        CustomContainer(OrderNames.order_clash_royale_diamond_passroyale),
    ]

    time_list = [
        CustomContainer(OrderNames.order_clash_royale_piggy_bank),
        CustomContainer(OrderNames.order_lash_royale_spec_1_monk),
        CustomContainer(OrderNames.order_lash_royale_spec_1_monk),
        CustomContainer(OrderNames.order_clash_royale_piggy_bank),
    ]
    
    gems_list = [
        CustomContainer(OrderNames.order_clash_royale_gems_80),
        CustomContainer(OrderNames.order_clash_royale_gems_500),
        CustomContainer(OrderNames.order_clash_royale_gems_1200),
        CustomContainer(OrderNames.order_clash_royale_gems_2500),
        CustomContainer(OrderNames.order_clash_royale_gems_6500),
        CustomContainer(OrderNames.order_clash_royale_gems_14000),
    ]
    
    
    passes_order_size = ft.Row(
        wrap=True,
        spacing=get_spacing(page.width, len(passes_list), order_sizes["Normal"]['width']),
        run_spacing=20,
        controls=passes_list,
        width=page.width,
        alignment=ft.MainAxisAlignment.CENTER,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )

    time_order_size = ft.Row(
        wrap=True,
        spacing=get_spacing(page.width, len(passes_list), order_sizes["Normal"]['width']),
        run_spacing=20,
        controls=time_list,
        width=page.width,
        alignment=ft.MainAxisAlignment.CENTER,
        vertical_alignment=ft.CrossAxisAlignment.START,
    )
    
    gems_order_size = ft.Row(
        wrap=True,
        spacing=get_spacing(page.width, len(gems_list), order_sizes["Small"]['width']),
        run_spacing=20,
        controls=gems_list,
        width=page.width,
        alignment=ft.MainAxisAlignment.CENTER,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
    )
    
    padding = ft.Row(height=25)

    bg_img = ft.Container(
        content = ft.Image(
            src="https://i.ibb.co/F6G0dGV/Clah-Royale-BG-Blue.png",
            fit=ft.ImageFit.COVER,
            opacity=0.4,
            scale=1.019,
            expand=True,
        ),
    )

    content = ft.Stack(
        controls=[
            ft.Column(
                controls=[
                    bg_img,
                    bg_img,
                    bg_img,
                ]
            ),
            ft.Column(
                controls=[
                    padding,
                    label_passes,
                    passes_order_size,
                    padding,
                    padding,
                    label_time,
                    time_order_size,
                    padding,
                    padding,
                    label_gems,
                    gems_order_size,
                ],
                scroll=ft.ScrollMode.ALWAYS,
            )
        ]
    )

    await page.add_async(
        content,
    )
    


# ft.app(target=main, view=ft.WEB_BROWSER, assets_dir="assets")
ft.app(target=main, assets_dir="assets")


# if __name__ == "__main__":
    #ft.app(target=main, view=None, port=8000)