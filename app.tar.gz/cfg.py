URL_TUNEL = "https://fa11-46-150-69-46.ngrok-free.app"

'''
tar -czvf app.tar.gz dialog_menu.py custom_container.py container_info.py cfg.py main.py orders.py requirements.txt
'''
