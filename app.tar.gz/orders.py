from enum import Enum


class OrderNames(Enum):
    order_clash_royale_gold_passroyale = 1,
    order_clash_royale_diamond_passroyale = 2,
    order_clash_royale_gems_80 = 3,
    order_clash_royale_gems_500 = 4,
    order_clash_royale_gems_1200 = 5,
    order_clash_royale_gems_2500 = 6,
    order_clash_royale_gems_6500 = 7,
    order_clash_royale_gems_14000 = 8,
    order_clash_royale_piggy_bank = 9,
    order_lash_royale_spec_1_monk = 10,