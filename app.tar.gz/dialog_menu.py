import flet as ft
from cfg import URL_TUNEL
from container_info import ContainerInfo
import requests



class DialogPayment(ft.UserControl):
    def __init__(self, page: ft.Page, info: ContainerInfo):
        super().__init__()

        self.page = page
        self.info : ContainerInfo = info
        self.confirm_button: ft.ElevatedButton
        self.content_column: ft.Column
        self.img: ft.Image
        self.txt_container: ft.Column
        self.dialog = self.get_menu()
        self.text_data: str
        self.error_text = ft.Text(value="Неверный id", color="0xEB4034")
        self.successfully_sended_text = ft.Text(value="Проверьте сообщения от бота!", color="0x30CC70")


    async def hide_dialog(self, e):
        self.dialog.open = False
        await self.page.update_async()

    async def on_click(self, e):
        input_chat_id = self.text_data.replace('@', '').replace(' ', '')

        r = requests.get(url=URL_TUNEL + f"/bot_token").json()
        r_bot_token = r['token']

        r = requests.get(url=URL_TUNEL + f"/contain_chat_id", params={"chat_id" : input_chat_id}).json()
        contains = r['ok']

        print(input_chat_id)
        print(contains)

        if (contains == False):
            self.content_column.controls.remove(self.img)
            self.content_column.controls.remove(self.txt_container)

            if (self.successfully_sended_text in self.content_column.controls):
                self.content_column.controls.remove(self.successfully_sended_text)

            if (self.error_text in self.content_column.controls):
                self.content_column.controls.remove(self.error_text)

            self.content_column.controls.insert(0, self.error_text)

            await self.page.update_async()
            return


        requests.post(url=f"https://api.telegram.org/bot{r_bot_token}/sendMessage?chat_id={input_chat_id}&text={input_chat_id}")

        prices = '[{"label":"' + self.info.text + '","amount":' + str(self.info.price*100) + '}]'

        requests.post(
            url=f"https://api.telegram.org/bot{r_bot_token}/sendinvoice",
            params={
                "chat_id": input_chat_id,
                "title": self.info.text,
                "description": "-",
                "currency": "RUB",
                "prices": prices,
                "payload": self.info.text,
                "provider_token": "1877036958:TEST:0867e41d2d635cde1c8e4961f87b08e430dc4eb6",
                "photo_url": self.info.img_url,
                "photo_height": 440,
                "photo_width": 640,
                "is_flexible": False,
                "need_email": True,
            }
        )

        self.content_column.controls.remove(self.img)
        self.content_column.controls.remove(self.txt_container)

        if (self.successfully_sended_text in self.content_column.controls):
                self.content_column.controls.remove(self.successfully_sended_text)

        if (self.error_text in self.content_column.controls):
            self.content_column.controls.remove(self.error_text)

        self.content_column.controls.insert(0, self.successfully_sended_text)

        await self.page.update_async()

    async def on_typing(self, e: ft.ControlEvent):
        self.text_data = e.data

        if len(e.data) >= 5:
            self.confirm_button.disabled = False
            await self.page.update_async()
        else:
            self.confirm_button.disabled = True
            await self.page.update_async()

    async def hide_info(self, e):
            self.content_column.controls.remove(self.img)
            self.content_column.controls.remove(self.txt_container)

            await self.page.update_async()

    async def show_info(self, e):
            self.content_column.controls.insert(0, self.img)
            self.content_column.controls.insert(1, self.txt_container)

            await self.page.update_async()

    def get_menu(self) -> ft.AlertDialog:
        info = self.info

        img = ft.Image(
            src=info.img_url,
            width=180,
            fit=ft.ImageFit.CONTAIN,
            border_radius=15,
        )
        self.img = img

        order_info_text = ft.Text(
            value=f"Покупка: ",
            size=11,
            weight=ft.FontWeight.W_400,
            spans=[
                ft.TextSpan(
                    f"{info.text}",
                    ft.TextStyle(size=13, weight=ft.FontWeight.NORMAL, font_family="Ubuntu-Regular",)
                ),
                ft.TextSpan(
                    f"\n\nЦена: ",
                    ft.TextStyle(size=11, weight=ft.FontWeight.NORMAL, font_family="KZSupercell-Magic",)
                ),
                ft.TextSpan(
                    f"{info.price} р",
                    ft.TextStyle(size=13, weight=ft.FontWeight.NORMAL, font_family="Ubuntu-Regular",)
                ),
                ft.TextSpan(
                    f"\n\nОписание: ",
                    ft.TextStyle(size=11, weight=ft.FontWeight.NORMAL, font_family="KZSupercell-Magic",)
                ),
                ft.TextSpan(
                    f"{info.desciption}",
                    ft.TextStyle(size=13, weight=ft.FontWeight.NORMAL, font_family="Ubuntu-Regular",)
                ),
            ],

            text_align=ft.TextAlign.START,
            color="0xFFFFFF",
            font_family="KZSupercell-Magic",
        )

        txt_container = ft.Container(
            content=ft.Column(
                controls=[
                    order_info_text
                ],
                scroll=ft.ScrollMode.ALWAYS,
            ),
            alignment=ft.alignment.center_left,
            width=300,
            margin=ft.Margin(0, 10, 0, 20),
        )

        txt_container = ft.Column(
            controls=[
                order_info_text
            ],

            height=120,
            scroll=ft.ScrollMode.HIDDEN,
        )
        self.txt_container = txt_container

        confirm_button = ft.ElevatedButton(
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=10),
            ),
            color="0xFFFFFF",
            bgcolor="0x30CC70",
            disabled=True,
            on_click=self.on_click,
            content=ft.Text(
                value="Перейти к оплате",
                size=10,
            )
        )
        self.confirm_button = confirm_button

        enter_username_text = ft.Text(
            value="Введите ваш id",
            size=8,
            text_align=ft.TextAlign.CENTER,
            color="0xFFFFFF",
            font_family="KZSupercell-Magic",
        )

        enter_username_field = ft.TextField(
            prefix_text="id: ",
            hint_text="12345678",
            width=200,
            height=30,
            max_lines=1,
            text_size=10,
            border="underline",
            on_change=self.on_typing,
            on_focus=self.hide_info,
            on_blur=self.show_info,
        )
        
        top_panel = ft.Stack(
            controls=[
                ft.Row(
                    controls= [
                        ft.IconButton(
                            icon=ft.icons.CLOSE,
                            icon_color="0xFFFFFF",
                            icon_size=18,
                            on_click=self.hide_dialog,
                        ),
                    ],

                    alignment=ft.MainAxisAlignment.START,
                    vertical_alignment=ft.CrossAxisAlignment.START,
                ),

                ft.Row(
                    controls= [
                        ft.Container(
                            content=ft.Text(
                                value="- ЧЕК -",
                                text_align=ft.TextAlign.END,
                                size=16,
                            ),
                            margin=ft.Margin(0, 11, 0, 0)
                        ),
                    ],
                    
                    alignment=ft.MainAxisAlignment.CENTER,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
            ],
        )
        
        padding = ft.Row(
            height=7
        )

        content_column = ft.Column(
            controls=[
                img,
                padding,
                txt_container,
                padding,
                enter_username_text,
                enter_username_field,
                confirm_button,
            ],
            scroll=ft.ScrollMode.HIDDEN,
            alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
        self.content_column = content_column

        input_container = ft.Container(
            content=ft.Column(
                controls=[
                    enter_username_text,
                    enter_username_field,
                    confirm_button,
                ],
                alignment=ft.MainAxisAlignment.END,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )

        container = ft.Container(
            ft.Stack(
                controls=[
                    content_column,
                    input_container,
                ]
            ),
            bgcolor=ft.colors.SECONDARY,
        ) 


        dlg = ft.AlertDialog(
            title=top_panel,
            on_dismiss=lambda e: print("Dialog dismissed!"),
            content=content_column
        )


        self.dialog = dlg
        return dlg
    
    def build(self):
        return self.dialog




async def show_dilaog(page: ft.Page, dlg: DialogPayment):
    dlg = dlg.build()

    page.dialog = dlg
    dlg.open = True
    await page.update_async()
